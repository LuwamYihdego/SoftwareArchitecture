package lab.seven.stockservice.domain;

public record Product(int productNumber, String productName ) {


}
