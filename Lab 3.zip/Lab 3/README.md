# SoftwareArchitecture
Daily projects for my SA course 
