package configservicea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigServiceAApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConfigServiceAApplication.class, args);
    }

}
