package configserviceb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServiceBApplicationTests {

    @Test
    void contextLoads() {
    }

}
