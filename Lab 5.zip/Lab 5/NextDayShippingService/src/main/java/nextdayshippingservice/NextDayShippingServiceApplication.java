package nextdayshippingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NextDayShippingServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(NextDayShippingServiceApplication.class, args);
    }

}
