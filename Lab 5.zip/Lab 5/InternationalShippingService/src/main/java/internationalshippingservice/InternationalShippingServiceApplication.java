package internationalshippingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternationalShippingServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(InternationalShippingServiceApplication.class, args);
    }

}
